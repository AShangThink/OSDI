/* This file use for NCTU OSDI course */
/* It's contants file operator's wapper API */
#include <fs.h>
#include <fat/ff.h>
#include <inc/string.h>
#include <inc/stdio.h>

/* Static file objects */
FIL file_objs[FS_FD_MAX];//10

/* Static file system object */
FATFS fat;

struct fs_fd fd_table[FS_FD_MAX];

extern struct fs_ops elmfat_ops; //We only one file system...
struct fs_dev fat_fs = {
    .dev_id = 1, //In this lab we only use second IDE disk
    .path = {0}, // Not yet mount to any path
    .ops = &elmfat_ops,
    .data = &fat
};

extern FILINFO fileinfo[10];
    
/*TODO: Lab7, VFS level file API.*/
int fs_init()
{
    FRESULT ret;
	int i;
    
    /* Initial fd_tables */
    for (i = 0; i < FS_FD_MAX; i++)
    {
        fd_table[i].flags = 0;
        fd_table[i].size = 0;
        fd_table[i].pos = 0;
        fd_table[i].type = 0;
        fd_table[i].ref_count = 0;
        fd_table[i].data = &file_objs[i];
        fd_table[i].fs = &fat_fs;

	//----my ls
	fileinfo[i].fsize = 0;
	fileinfo[i].fattrib = -1;
	strncpy(fileinfo[i].fname,"",13);
	
    }
    
    /* Mount fat file system at "/" */
    /* Check need mkfs or not */
    if ((ret = fs_mount("elmfat", "/", NULL)) != 0)
    {
        fat_fs.ops->mkfs("elmfat");
        ret = fs_mount("elmfat", "/", NULL);
	return ret;
    }
    
	return -STATUS_EIO;  
}
int fs_mount(const char* device_name, const char* path, const void* data)
{
	//fat_mount(struct fs_dev *fs, unsigned long rwflag, const void* data);
	FRESULT ret;

	//strcpy(fat_fs.path, path);
	if(strcmp(fat_fs.ops->dev_name, device_name)==0)
	{
		strcpy(fat_fs.path,path);
		return fat_mount(&fat_fs, data);
	}

	return -STATUS_EIO;
} 

int file_read(struct fs_fd* fd, void *buf, size_t len)
{
	//fat_read(struct fs_fd* file, void* buf, size_t count);
	//printk("in file_read\n");
	return fat_read(fd, buf, len);
}

int file_write(struct fs_fd* fd, const void *buf, size_t len)
{
	//fat_write(struct fs_fd* file, const void* buf, size_t count);
	//printk("in file_write\n");

	int i=0;
	FRESULT ret = fat_write(fd, buf, len);
	if(ret > 0)
	{
		while(strcmp(fd->path,fileinfo[i].fname)!=0) i++;

		if(i>=0 && i<FS_FD_MAX) fileinfo[i].fsize += len;
	}
	return ret;
}

int file_open(struct fs_fd* fd, const char *path, int flags)
{
	if(fd != NULL){
		strncpy(fd->path, path,64);
		fd->flags = flags;
		fd->type = 1;//type = 1: FILE 2:SOCKET 3:NON
		fd->size = 0;
		//printk("file_open do it\n");	

		//----my ls
		int i=0, find=-1;
		for(i=0;i<FS_FD_MAX;i++)
		{
			
			if(fileinfo[i].fattrib == 255)
			{
				find = i;
				fileinfo[i].fsize = fd->size;
				fileinfo[i].fattrib = 1;//set mapping no
				strncpy(fileinfo[i].fname,path,13);
				//printk("i=%d fsize=%d fatrrib=%d fname=%s\n",i,fileinfo[i].fsize,fileinfo[i].fattrib,fileinfo[i].fname);
				break;
			}
		}
		if(find==-1) printk("no maintain\n");
				

		return fat_open(fd);
	}else{
		//printk("can not do it\n");
		return -1;
	}
}

int file_close(struct fs_fd* fd)
{
	//fat_close(struct fs_fd* file);
	
	return fat_close(fd);
}

int file_lseek(struct fs_fd* fd, off_t offset)
{	
	//fat_lseek(struct fs_fd* file, off_t offset);
	return fat_lseek(fd, offset);
}

int file_unlink(const char *path)
{
	//fat_unlink(struct fs_fd* file, const char *pathname);
	return fat_unlink(NULL,path);
}

int file_ls()
{
	//printk("in file_ls\n");
	/*
	int i = 0;		
	for(i=0;i<FS_FD_MAX;i++)
	{
		if(fileinfo[i].fattrib == 1)
		{
			printk("%s type:%s size:%d\n", fileinfo[i].fname, "FILE", fileinfo[i].fsize);
		}
	}
	*/
	fat_ls();
	return 0;
}


/**
 * @ingroup Fd
 * This function will allocate a file descriptor.
 *
 * @return -1 on failed or the allocated file descriptor.
 */
int fd_new(void)
{
	struct fs_fd* d;
	int idx;

	/* find an empty fd entry */
	for (idx = 0; idx < FS_FD_MAX && fd_table[idx].ref_count > 0; idx++);


	/* can't find an empty fd entry */
	if (idx == FS_FD_MAX)
	{
		idx = -1;
		goto __result;
	}

	d = &(fd_table[idx]);
	d->ref_count = 1;

__result:
	return idx;
}

/**
 * @ingroup Fd
 *
 * This function will return a file descriptor structure according to file
 * descriptor.
 *
 * @return NULL on on this file descriptor or the file descriptor structure
 * pointer.
 */
struct fs_fd* fd_get(int fd)
{
	struct fs_fd* d;

	if ( fd < 0 || fd > FS_FD_MAX ) return NULL;

	d = &fd_table[fd];

	/* increase the reference count */
	d->ref_count ++;

	return d;
}

/**
 * @ingroup Fd
 *
 * This function will put the file descriptor.
 */
void fd_put(struct fs_fd* fd)
{

	fd->ref_count --;

	/* clear this fd entry */
	if ( fd->ref_count == 0 )
	{
		//memset(fd, 0, sizeof(struct fs_fd));
		memset(fd->data, 0, sizeof(FIL));
	}
};


