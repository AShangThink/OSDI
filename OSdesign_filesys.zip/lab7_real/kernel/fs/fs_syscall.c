/* This file use for NCTU OSDI course */

// It's handel the file system APIs 
#include <inc/stdio.h>
#include <inc/syscall.h>
#include <fs.h>


#include <fat/ff.h>


extern struct fs_fd fd_table[FS_FD_MAX];
extern FIL file_objs[FS_FD_MAX];




/*TODO: Lab7, file I/O system call interface.*/
/*NOte: Here you need handle the file system call from user.
*       1. When user open a new file, you can use the fd_new() to alloc a file object(struct fs_fd)
*       2. When user R/W the file, use the fd_get() to get file object.
*       3. After get file object call file_* functions into VFS level
*       4. Update the file objet's position or size when user R/W or seek the file.(You can find the useful marco in ff.h)
*       5. Handle the error code, for example, if user call open() but no fd slot can be use, sys_open should return -STATUS_ENOSPC.
*/
// Below is POSIX like I/O system call 
int sys_open(const char *file, int flags, int mode)
{
    //We dont care the mode.
/* TODO */
	//file_open(struct fs_fd* fd, const char *path, int flags);
	//printk("in sys_open\n");

	int idx;	
	struct fs_fd* fd_open;
	FRESULT ret;
	
	//printk("flags = %x, %x, %x %x %x\n",flags, O_WRONLY | O_CREAT | O_TRUNC, O_WRONLY, O_CREAT, O_TRUNC);

	//printk("%d\n",(flags - O_WRONLY | O_CREAT == 0x0)?1:0);

	//if(flags==O_WRONLY) return -STATUS_ENOENT;
	//if((flags & O_TRUNC != 0x0001000)) return -STATUS_EEXIST;
	

	idx = fd_new();
	//printk("idx = %d\n",idx);
	if(idx>=0 && idx<=9){ 

		//printk("in %x, idx %d\n",flags,idx);

		fd_open = fd_get(idx);
		fd_open->ref_count = 1;
		ret = file_open(fd_open, file, flags);
		//printk("ret = %d\n",ret);
		
		if(ret == FR_OK){//FR_OK
			return idx;
		}else{	
			fd_open->ref_count = 0;
			fd_put(fd_open);
			return ret;
		}
	}else return idx;
}

int sys_close(int fd)
{
/* TODO */
	//file_close(struct fs_fd* fd));
	//printk("in sys_close ");
	
	FRESULT ret;
	if(fd >= FS_FD_MAX) return -STATUS_EINVAL;
	struct fs_fd* fd_close = fd_get(fd);

 
	fd_close->ref_count--;
	ret = file_close(fd_close);
	fd_put(fd_close);
	
	return ret;

	/*
	switch(ret)
	{
		case FR_OK:
		return STATUS_OK;
	}	
	
	return STATUS_EIO; //error
	*/
}

int sys_read(int fd, void *buf, size_t len)
{
/* TODO */
	//file_read(struct fs_fd* fd, void *buf, size_t len);

	FRESULT ret; 

	if((int)len<0)
		return -STATUS_EINVAL;
	if(fd>= FS_FD_MAX||fd<0)
		return -STATUS_EBADF;	
	if(buf == 0)
		return -STATUS_EINVAL;

	struct fs_fd* fd_read = fd_get(fd);
	if(fd_read != NULL && buf != NULL && len>=0){ 
		ret = file_read(fd_read, buf, len);
		fd_put(fd_read);
		return ret;//STATUS_EIO;
	}

	
}

int sys_write(int fd, const void *buf, size_t len)
{
/* TODO */
	//file_write(struct fs_fd* fd, const void *buf, size_t len);
	
	//printk("in sys_write %s %d %d\n",fd_table[fd].path, fd_table[fd].type, fd_table[fd].ref_count);
	//printk("%d %s \n",fd_table[fd].fs->dev_id, fd_table[fd].fs->path);
	//printk("%d\n",file_objs[fd].flag);	
	FRESULT ret;

	if((fd >= FS_FD_MAX)||(fd<0))
		return -STATUS_EBADF;
	if((int)len<0)
		return -STATUS_EINVAL;
	 
	struct fs_fd* fd_write = fd_get(fd);
	if(fd_write != NULL && buf != NULL && len>=0){
		ret = file_write(fd_write, buf, len);
		fd_put(fd_write);
		return ret;
	}

	
	
	//printk("in sys_write, res = %d\n",res);

	/*	
	switch(ret)
	{
		case FR_INT_ERR:
		return STATUS_EIO;
		case FR_DISK_ERR:
		return STATUS_EIO;
		case FR_OK:
		return STATUS_OK;
	}
	*/	
	
}

off_t sys_lseek(int fd, off_t offset, int whence)
{
/* TODO */
	//file_lseek(struct fs_fd* fd, off_t offset);
	off_t newoffset;
	FRESULT ret;

	if(fd >= FS_FD_MAX || fd<0)
		return -STATUS_EINVAL;

	struct fs_fd* fd_lseek = fd_get(fd);

	switch(whence){
	case SEEK_SET:
		newoffset = offset;
		break;
	case SEEK_CUR:
		newoffset = (off_t)(fd_lseek->pos);
	case SEEK_END:
		newoffset = (off_t)(fd_lseek->size)+offset;
		break;
	}

	ret = file_lseek(fd_lseek, newoffset);
	fd_put(fd_lseek);
	return ret;
}

int sys_unlink(const char *pathname)
{
/* TODO */
	//int file_unlink(const char *path);


	FRESULT ret = file_unlink(pathname);
	return ret;	
}

int sys_ls(void)
{
	//printk("in sys_ls\n");
	file_ls();
	return 0;
}
              

