/* This file use for NCTU OSDI course */
#include <fs.h>
#include <fat/diskio.h>
#include <fat/ff.h>
#include <kernel/drv/disk.h>

#define DISK_ID 1





#define MAX_DRIVES	10	/* Max number of physical drives to be used */
#define	BUFSIZE 262144UL	/* Size of data transfer buffer */

static BYTE *Buffer;	/* Poiter to the data transfer buffer */



/*TODO: Lab7, low level file operator.*/
DSTATUS disk_initialize (BYTE pdrv)
{
    //printk("disk_initialize %d\n", pdrv);
    /* TODO */
	/*
	DSTATUS stat;
	int result = disk_init();//get 0
	stat = result;
	return stat;
	*/

	DSTATUS sta;
	
	if (pdrv >= MAX_DRIVES) {
		sta = STA_NODISK;
	} else {
		if(ide_devices[DISK_ID].Reserved == 0) 
		{
			disk_init();
			sta = 0;
		}
		else sta = STA_NOINIT;
	}

	return sta;
}
DSTATUS disk_status (BYTE pdrv)
{
    //printk("disk_status\n");
    /* TODO */
	if(ide_devices[DISK_ID].Reserved == 0) return STA_NOINIT;
	else return 0; 
}
DRESULT disk_read (BYTE pdrv, BYTE* buff, DWORD sector, UINT count)
{
    /* TODO */
	
	//ide_read_sectors(unsigned char drive, unsigned char numsects, unsigned int lba, unsigned int edi);
	/*
	DSTATUS stat;
	int result = ide_read_sectors(pdrv, 1, sector, count);//get 0
	stat = result;
	return RES_OK;
	*/

	DWORD nc;
	DSTATUS res;

	if (pdrv >= MAX_DRIVES)
		return RES_NOTRDY;

	nc = (DWORD)count * sector;
	if (pdrv) {
		if (nc > BUFSIZE) {
			res = RES_PARERR;
		} else {
			int i=0;
			for(i=0;i<count;i++)
			{
				if (!ide_read_sectors(pdrv, 1, sector, *buff+512*i)) {
					res = RES_ERROR;
				}
			}
			
			//memcpy(buff, Buffer, nc);
			res = RES_OK;
		}
	}

	return res;
}
DRESULT disk_write (BYTE pdrv, const BYTE* buff, DWORD sector, UINT count)
{
    /* TODO */  
	/*
	//ide_read_sectors(unsigned char drive, unsigned char numsects, unsigned int lba, unsigned int edi);
	DSTATUS stat;
	int result = ide_read_sectors(pdrv, 1, sector, count);//get 0
	stat = result;
	return RES_OK;
	*/

	/*
	DWORD nc;
	DRESULT res;

	if (pdrv >= MAX_DRIVES)
		return RES_NOTRDY;

	nc = (DWORD)count * sector;
	if (pdrv) {
		if (nc > BUFSIZE) {
			res = RES_PARERR;
		} else {
			int i=0;
			for(i=0;i<count;i++)
			{
				if (!ide_write_sectors(DISK_ID, 1, sector, *buff+512*i)) {
					res = RES_ERROR;
				}
			}
			
			//memcpy(buff, Buffer, nc);
			res = RES_OK;
		}
	}

	return res;
	*/

	int i = count;
	BYTE *ptr = buff;
	UINT cur_sector = sector;

	ide_write_sectors(DISK_ID, count, cur_sector, (unsigned int)ptr);
	return RES_OK;	
}
DRESULT disk_ioctl (BYTE pdrv, BYTE cmd, void* buff)
{
    //uint32_t *retVal = (uint32_t *)buff;
    //printk("disk_ioctl drv=%d cmd=%d\n", pdrv, cmd);
    /* TODO */

	switch(cmd)
	{
		case GET_SECTOR_COUNT:
			buff = ide_devices[DISK_ID].Size;
		return RES_OK;
		case GET_SECTOR_SIZE:
		case GET_BLOCK_SIZE:
			buff = 512;
		return RES_OK;
	}

	return 0;
}

DWORD get_fattime (void)
{
    /* TODO */
    return get_ticks();   
}
