/* This file use for NCTU OSDI course */
/* It's contants fat file system operators */

#include <inc/stdio.h>
#include <fs.h>
#include <fat/ff.h>
#include <diskio.h>

extern struct fs_dev fat_fs;




/*TODO: Lab7, fat level file operator.
*       Implement below functions to support basic file system operators by using the elmfat's API(f_xxx).
*       Reference: http://elm-chan.org/fsw/ff/00index_e.html
*/

/* Note: 1. Get FATFS object from fs->data
*        2. Check fs->path parameter then call f_mount.
*/
int fat_mount(struct fs_dev *fs, const void* data)
{
	//FRESULT f_mount(FATFS* fs, const TCHAR* path, BYTE opt);
	/*
	fs = &fat_fs;
	FIL *fsdata = (FIL*)fs->data;
	FATFS* fatfs = fsdata->obj.fs;//((FIL*)fs->data).obj.fs;
	return f_mount(fatfs, (const TCHAR)&(fat_fs.path), 1);
	*/
	int res;
	res = f_mount((FIL*)fs->data, fs->path,1 );
	return res;
}

int fat_mkfs(const char* device_name)
{
	//FRESULT f_mkfs(const TCHAR* path, BYTE sfd, UINT au);
	
	return f_mkfs("/", 0, 0);
	
}
int fat_open(struct fs_fd* file)
{
	//FRESULT f_open(FIL* fp, const TCHAR* path, BYTE mode);
	//printk("in fat_open\n");
	

	/*
	#define O_RDONLY		0x0000000
	#define O_WRONLY		0x0000001
	#define O_RDWR			0x0000002
	#define O_ACCMODE		0x0000003
	#define O_CREAT			0x0000100
	#define O_EXCL			0x0000200
	#define O_TRUNC			0x0001000
	#define O_APPEND		0x0002000
	#define O_DIRECTORY		0x0200000
	*/

	/*
	#define	FA_READ				0x01
	#define	FA_WRITE			0x02
	#define	FA_OPEN_EXISTING	0x00
	#define	FA_CREATE_NEW		0x04
	#define	FA_CREATE_ALWAYS	0x08
	#define	FA_OPEN_ALWAYS		0x10
	#define _FA_MODIFIED		0x20
	#define _FA_DIRTY			0x40
	*/

	

	FRESULT ret;
	TCHAR* path;
	int flag = 0;//file->flags


	switch(file->flags & 0x0f)
	{
	case O_RDONLY:
		flag = FA_READ;
		break;
	case O_WRONLY:
		//printk("in O_WRONLY\n");
		flag = FA_WRITE;
		break;
	case O_RDWR:
		flag = FA_READ | FA_WRITE;
		break;
	case O_ACCMODE:
		flag = FA_READ | FA_WRITE;		
		break;
	}

	switch(file->flags & 0xf00)
	{
	case O_CREAT:
		if(file->flags & O_TRUNC ){
			flag |= FA_CREATE_ALWAYS;
			//printk("in O_CREAT O_TRUNC\n");
		}else flag |= FA_CREATE_NEW;
		break;
	}

		

	path = file->path;
	ret = f_open((FIL*)file->data, path, flag);
	switch(ret){
		case FR_NO_FILE:
		case FR_NO_PATH:
			ret = -STATUS_ENOENT;
			break;
		case FR_EXIST:
			ret = -STATUS_EEXIST;
			break;
		default:
			ret = -ret;

	}
	return ret;
}
int fat_close(struct fs_fd* file)
{
	//FRESULT f_close(FIL* fp);
	int ret;
	ret  = f_close((FIL*)file->data);	
	switch(ret){
		case FR_OK :
			return ret;
		case FR_DISK_ERR:
			return -STATUS_EIO;
		case FR_INT_ERR:
/*TODO*/		return -ret;

		case FR_INVALID_OBJECT:
			return -STATUS_EINVAL; 	
		case FR_TIMEOUT:
			return -ret;	
	}
	return ret;
}

int fat_read(struct fs_fd* file, void* buf, size_t count)
{
	//FRESULT f_read(FIL* fp, void* buff, UINT btr, UINT* br);
	UINT br;
	FRESULT ret;
	//printk("in fat_read, file->size = %d\n",file->size);
	
	ret = f_read((FIL*)file->data, buf, count, &br);
	
	if(ret == FR_OK) return br;
	else return -ret;
}

int fat_write(struct fs_fd* file, const void* buf, size_t count)
{
	//FRESULT f_write(FIL* fp, const void* buff, UINT btw, UINT* bw);

	UINT bw;
	FRESULT ret;
	
	ret = f_write((FIL*)file->data, buf, count, &bw);
	
	if(ret == FR_OK){
		file->size+=bw;		
		return bw;//bw
	}else return -ret;
}
int fat_lseek(struct fs_fd* file, off_t offset)
{
	//FRESULT f_lseek(FIL* fp, FSIZE_t ofs);
	return f_lseek((FIL*)file->data, offset);	
}
int fat_unlink(struct fs_fd* file, const char *pathname)
{
	//FRESULT f_unlink(const TCHAR* path);
	FRESULT ret = f_unlink(pathname);


	switch(ret)
	{
	case FR_NO_FILE:
	 	return -STATUS_ENOENT;
	default:
		return ret;
	} 
}

int fat_ls()
{
	//return FR_OK;

	FRESULT res;
    	DIR dir;
    	UINT i;
    	static FILINFO fno;
	char path[30]="/";


    	res = f_opendir(&dir, path);                       /* Open the directory */
    	if (res == FR_OK) {
		for(;;){
            		res = f_readdir(&dir, &fno);                   /* Read a directory item */
            		if (res != FR_OK || fno.fname[0] == 0) break;  /* Break on error or end of dir */
            		if (fno.fattrib & AM_DIR) {                    /* It is a directory */
                		printk(&path[i = strlen(path)], "/%s", fno.fname);
                		//res = scan_files(path);                    /* Enter the directory */
                		//if (res != FR_OK) break;
                		path[i] = 0;
            		} else {                                       /* It is a file. */
                		printk("NAME:%s TYPE:file %d SIZE:%d\n", fno.fname, fno.fattrib, fno.fsize);
            		}
        	}
        	f_closedir(&dir);
    	}

    return res;

}



struct fs_ops elmfat_ops = {
    .dev_name = "elmfat",
    .mount = fat_mount,
    .mkfs = fat_mkfs,
    .open = fat_open,
    .close = fat_close,
    .read = fat_read,
    .write = fat_write,
    .lseek = fat_lseek
};



