#ifndef TIMER_H
#define TIMER_H
void timer_init();
unsigned long get_tick();
#endif
